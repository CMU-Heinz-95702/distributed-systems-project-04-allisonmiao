//name:Allison Miao
//andrewid:yuhanmia
package ds.project4task2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private EditText etCity;
    private Button btnFetch;
    private TextView tvResults;

    //private static final String BASE_URL = "http://100.110.161.66:8080/Project4Task2_war_exploded/cityinfo?city="; // Replace with your LAN IP for physical devices
    private static final String BASE_URL ="https://opulent-doodle-97j99p6r5vrvf954j-8080.app.github.dev/cityinfo?city=";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCity = findViewById(R.id.etCity);
        btnFetch = findViewById(R.id.btnFetch);
        tvResults = findViewById(R.id.tvResults);

        btnFetch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String city = etCity.getText().toString().trim();
                if (city.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a city name", Toast.LENGTH_SHORT).show();
                } else {
                    fetchCityInfo(city);
                }
            }
        });
    }

    private void fetchCityInfo(String city) {
        String url = BASE_URL + city;

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                    tvResults.setText("Error: " + e.getMessage());
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseBody = response.body().string();

                    // Parse the JSON response
                    JsonArray jsonArray = JsonParser.parseString(responseBody).getAsJsonArray();
                    if (jsonArray.size() > 0) {
                        JsonObject cityInfo = jsonArray.get(0).getAsJsonObject();
                        StringBuilder result = new StringBuilder();

                        result.append("City: ").append(cityInfo.get("name").getAsString()).append("\n");
                        result.append("Country: ").append(cityInfo.get("country").getAsString()).append("\n");
                        result.append("Population: ").append(cityInfo.get("population").getAsString()).append("\n");
                        result.append("Latitude: ").append(cityInfo.get("latitude").getAsString()).append("\n");
                        result.append("Longitude: ").append(cityInfo.get("longitude").getAsString()).append("\n");

                        runOnUiThread(() -> tvResults.setText(result.toString()));
                    } else {
                        runOnUiThread(() -> tvResults.setText("No data found for the city."));
                    }
                } else {
                    runOnUiThread(() -> {
                        Toast.makeText(MainActivity.this, "Error fetching data", Toast.LENGTH_SHORT).show();
                        tvResults.setText("Response code: " + response.code());
                    });
                }
            }
        });
    }
}

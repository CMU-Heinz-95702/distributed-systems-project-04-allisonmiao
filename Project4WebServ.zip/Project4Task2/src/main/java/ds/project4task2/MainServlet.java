//name:Allison Miao
//andrewid:yuhanmia
package ds.project4task2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainServlet extends HttpServlet {

    private static final String API_URL_TEMPLATE = "https://api.api-ninjas.com/v1/city?name=%s&limit=1";
    private static final String API_KEY = "/OTgm/6L0v3cLFfbkP4ZJA==Pi6GMdcERHbak59o";
    private static final String MONGO_CONNECTION_STRING = "mongodb+srv://yuhanmia:project4@project4.zbdu0.mongodb.net/?retryWrites=true&w=majority&appName=Project4";
    private static final String MONGO_DATABASE_NAME = "project4task2";
    private static final String MONGO_COLLECTION_NAME = "logs";

    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        // Set up the MongoDB client and connect to the logs collection
        MongoClient mongoClient = MongoClients.create(MONGO_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(MONGO_DATABASE_NAME);
        logCollection = database.getCollection(MONGO_COLLECTION_NAME);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException {
        String city = req.getParameter("city");

        // Handle invalid input
        if (city == null || city.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.setContentType("application/json");
            try {
                resp.getWriter().write("{\"error\": \"Invalid city name.\"}");
            } catch (Exception e) {
                e.printStackTrace();
            }
            return;
        }

        try {
            // Create a log document to track request details
            Document log = new Document();
            log.append("mobile_timestamp", System.currentTimeMillis())
                    .append("city", city)
                    .append("user_agent", req.getHeader("User-Agent"));

            // Build the API URL
            String apiUrl = String.format(API_URL_TEMPLATE, city);
            log.append("api_request_timestamp", System.currentTimeMillis());

            // Fetch data from the third-party API
            long startTime = System.currentTimeMillis();
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setRequestProperty("X-Api-Key", API_KEY);

            int responseCode = connection.getResponseCode();
            long endTime = System.currentTimeMillis();
            log.append("api_response_time", endTime - startTime);

            if (responseCode == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = in.readLine()) != null) {
                    response.append(line);
                }
                in.close();

                // Log the successful response to the mobile app
                log.append("mobile_response_data", response.toString())
                        .append("mobile_response_timestamp", System.currentTimeMillis());

                // Save the log to MongoDB
                logCollection.insertOne(log);

                // Send the response back to the Android app
                resp.setContentType("application/json");
                resp.setStatus(HttpServletResponse.SC_OK);
                resp.getWriter().write(response.toString());
            } else {
                // Log the error response
                log.append("mobile_response_error", "Failed to fetch data from the API")
                        .append("mobile_response_timestamp", System.currentTimeMillis());

                // Save the log to MongoDB
                logCollection.insertOne(log);

                // Handle error response from third-party API
                resp.setContentType("application/json");
                resp.setStatus(HttpServletResponse.SC_BAD_GATEWAY);
                resp.getWriter().write("{\"error\": \"Failed to fetch data from the API.\"}");
            }

        } catch (Exception e) {
            // Log server error
            Document errorLog = new Document();
            errorLog.append("mobile_timestamp", System.currentTimeMillis())
                    .append("city", city)
                    .append("error", e.getMessage());

            logCollection.insertOne(errorLog);

            // Handle server errors
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.setContentType("application/json");
            try {
                resp.getWriter().write("{\"error\": \"An error occurred on the server.\"}");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

//name:Allison Miao
//andrewid:yuhanmia

package ds.project4task2;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

public class DashboardServlet extends HttpServlet {

    private static final String MONGO_CONNECTION_STRING = "mongodb+srv://yuhanmia:project4@project4.zbdu0.mongodb.net/?retryWrites=true&w=majority&appName=Project4";
    private static final String MONGO_DATABASE_NAME = "project4task2";
    private static final String MONGO_COLLECTION_NAME = "logs";

    private MongoCollection<Document> logCollection;

    @Override
    public void init() throws ServletException {
        super.init();
        // Set up the MongoDB client and connect to the logs collection
        MongoClient mongoClient = MongoClients.create(MONGO_CONNECTION_STRING);
        MongoDatabase database = mongoClient.getDatabase(MONGO_DATABASE_NAME);
        logCollection = database.getCollection(MONGO_COLLECTION_NAME);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();

        out.println("<html><head><title>Web Service Dashboard</title></head><body>");
        out.println("<h1>Web Service Dashboard</h1>");

        // Analytics Section
        out.println("<h2>Operations Analytics</h2>");

        // Calculate analytics
        Map<String, Integer> cityCounts = new HashMap<>();
        long totalLatency = 0;
        int totalRequests = 0;

        for (Document log : logCollection.find()) {
            String city = log.getString("city");
            cityCounts.put(city, cityCounts.getOrDefault(city, 0) + 1);

            if (log.containsKey("api_response_time")) {
                totalLatency += log.getLong("api_response_time");
            }

            totalRequests++;
        }

        // Calculate average latency
        double averageLatency = totalRequests > 0 ? (double) totalLatency / totalRequests : 0;

        // Display analytics
        out.println("<p><b>Top Cities Requested:</b> " + cityCounts + "</p>");
        out.println("<p><b>Total Requests:</b> " + totalRequests + "</p>");
        out.println("<p><b>Average API Response Time:</b> " + averageLatency + " ms</p>");

        // Logs Section
        out.println("<h2>Logs</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Mobile Timestamp</th><th>City</th><th>User Agent</th><th>API Response Time</th><th>Response Data</th></tr>");

        // Display logs
        for (Document log : logCollection.find()) {
            out.println("<tr>");
            out.println("<td>" + log.get("mobile_timestamp") + "</td>");
            out.println("<td>" + log.get("city") + "</td>");
            out.println("<td>" + log.get("user_agent") + "</td>");
            out.println("<td>" + log.get("api_response_time") + " ms</td>");
            out.println("<td>" + log.get("mobile_response_data") + "</td>");
            out.println("</tr>");
        }
        out.println("</table>");

        out.println("</body></html>");
    }
}
